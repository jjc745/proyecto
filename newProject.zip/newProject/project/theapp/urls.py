from django.urls import path
from .views import IndexView, Pagina1View, Pagina2View

urlpatterns = [
    path('', IndexView.as_view(), name='index'),
    path('search.html', Pagina1View.as_view(), name='searc.html'),
    path('team.html', Pagina2View.as_view(), name='team.html'),
]
