from django.views.generic import TemplateView

class BaseView(TemplateView):
    template_name = 'theapp/base.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['titulo'] = self.title
        return context

class IndexView(BaseView):
    title = 'Inicio'
    template_name = 'theapp/index.html'

class Pagina1View(BaseView):
    title = 'Página 1'
    template_name = 'theapp/search.html'

class Pagina2View(BaseView):
    title = 'Página 2'
    template_name = 'theapp/team.html'
